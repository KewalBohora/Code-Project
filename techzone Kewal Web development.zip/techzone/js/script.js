document.getElementById("contactForm")?.addEventListener("submit", function(e) {
    e.preventDefault();

    let name = document.getElementById("name").value.trim();
    let email = document.getElementById("email").value.trim();
    let message = document.getElementById("message").value.trim();
    let output = document.getElementById("formMessage");

    if (name === "" || email === "" || message === "") {
        output.style.color = "red";
        output.innerText = "Please fill in all required fields.";
        return;
    }

    if (!email.includes("@")) {
        output.style.color = "red";
        output.innerText = "Please enter a valid email address.";
        return;
    }

    output.style.color = "green";
    output.innerText = "Message sent successfully!";
});